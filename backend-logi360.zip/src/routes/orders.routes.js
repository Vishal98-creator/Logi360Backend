const express = require("express");
const { verifyToken } = require("../middleware/veriftToken");
const { uploadToS3 } = require("../controllers/order.controller");

const orderRouter = express.Router(); // ✅ FIXED LINE

orderRouter.post("/upload-csv", uploadToS3);

module.exports = orderRouter;
