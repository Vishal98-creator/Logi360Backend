const AWS = require("aws-sdk");
const multer = require("multer");
const multerS3 = require("multer-s3"); // ✅ REQUIRED
const { PrismaClient } = require("@prisma/client");

console.log("S3_BUCKET_NAME:", process.env.S3_BUCKET_NAME);

// ✅ Configure AWS
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();

// ✅ Multer S3 storage setup
const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: process.env.S3_BUCKET_NAME,
    acl: "public-read", // or 'private'
    metadata: (req, file, cb) => {
      cb(null, { fieldName: file.fieldname });
    },
    key: (req, file, cb) => {
      cb(null, `uploads/${Date.now().toString()}-${file.originalname}`);
    },
  }),
}).single("image"); // Use 'image' as the form-data key

// ✅ Exported controller function
exports.uploadToS3 = (req, res) => {
  upload(req, res, function (err) {
    if (err) {
      console.error("Upload error:", err);
      return res.status(500).json({ error: "Error uploading file", details: err.message });
    }
    console.log("File uploaded:", req.file);
    res.status(200).json({
      message: "Upload successful",
      fileUrl: req.file.location,
    });
  });
};
